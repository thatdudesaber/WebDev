<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Wochenkarte</title>
</head>
<body>
    

    <div class="container">
        <form action="index.php" method="post" class="">
            <h3>Wochenkarte</h3>
            <label for="email">Email</label>
            <input type="text" id="email" required>
            <label for="password">Passwort</label>
            <input type="text" id="password" required>
        </form>
    </div>


</body>
</html>